//
//  enum.cpp
//  P2
//
//  Created by Samuel Zurowski on 4/6/19.
//  Copyright © 2019 Samuel Zurowski. All rights reserved.
//

#pragma once

//list of moveTypes that are used
enum moveType {ATTACK_ONE, ATTACK_TWO, HEAL};
